﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RNutzenbergerICA9
{
    public partial class ica12_RyanNutzenberger : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                NorthwindAccess.FillCustomersDDL("", _DDLCust);
            }
        }

        protected void _btnFilter_Click(object sender, EventArgs e)
        {
            //fill the DDL using the filter form the textbox
            NorthwindAccess.FillCustomersDDL(_txbFilter.Text, _DDLCust);
            //reset the gridview
            _gvSummary.DataSource = null;
            //_gvSummary.Columns.Clear();
            _gvSummary.DataBind();
        }

        protected void _DDLCust_SelectedIndexChanged(object sender, EventArgs e)
        {
            //return if they select the first index
            if(_DDLCust.SelectedIndex == 0)
            {
                return;
            }
            //else populate the gridview
            _gvSummary.DataSource = NorthwindAccess.CustomerCategorySummary(_DDLCust.SelectedValue);
            _gvSummary.DataBind();
        }

        protected void _gvSummary_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //as long as the current row isnt the header, set appropriate formatting
            if(e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[1].HorizontalAlign = HorizontalAlign.Center;
                e.Row.Cells[2].HorizontalAlign = HorizontalAlign.Right;
                double val = double.Parse(e.Row.Cells[2].Text);
                e.Row.Cells[2].Text = String.Format("{0:c}", val);
            }
        }
    }
}