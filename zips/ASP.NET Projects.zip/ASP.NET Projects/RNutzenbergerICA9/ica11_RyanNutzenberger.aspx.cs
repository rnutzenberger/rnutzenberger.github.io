﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

namespace RNutzenbergerICA9
{
    public partial class ica11_RyanNutzenberger : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //initial DDL build
            if (!IsPostBack)
            {
                FillDDLSupps(_DDLSupp, "");
            }
        }

        //Builds the DDL with text/value fields
        protected void FillDDLSupps(DropDownList ddl, string sFilter)
        {
            //clear values before binding
            ddl.AppendDataBoundItems = true;
            //get sql datasource from data access layer
            ddl.DataSource = NorthwindAccess.GetSuppliersSDS(sFilter);

            //set the text to the company name, valie to the ID
            ddl.DataTextField = "CompanyName";
            ddl.DataValueField = "SupplierID";
            //clear previous items
            ddl.Items.Clear();

            //bind the data to the ddl
            ddl.DataBind();

            //insert and inital item witht he company count, and set autoPostBakc to true
            ddl.Items.Insert(0, new ListItem($"Pick a Company From [{ddl.Items.Count}]", ""));
            ddl.AutoPostBack = true;


        }

        protected void _btnFilter_Click(object sender, EventArgs e)
        {
            //filters the ddl based on the textbox text
            FillDDLSupps(_DDLSupp, _txbFIlter.Text);
        }


        protected void _DDLSupp_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if the selected value is the dummy value, return nothing
            if(_DDLSupp.SelectedValue == "0")
            {
                return;
            }

            //call the helper function using the selected ddl value
            var output = NorthwindAccess.GetProducts(_DDLSupp.SelectedValue);

            //create the header row
            TableHeaderRow headerRow = new TableHeaderRow();
            TableHeaderCell headerCell1 = new TableHeaderCell();
            TableCell headerCell2 = new TableHeaderCell();
            TableCell headerCell3 = new TableHeaderCell();

            //assign text to the first list of string values
            headerCell1.Text = output[0][0];
            headerCell2.Text = output[0][1];
            headerCell3.Text = output[0][2];
            //add to the header row
            headerRow.Cells.Add(headerCell1);
            headerRow.Cells.Add(headerCell2);
            headerRow.Cells.Add(headerCell3);
            //add header row to the table
            _tblProducts.Rows.Add(headerRow);

            //remove the first list containing the headers
            output.Remove(output[0]);

            //iterate through, doing same thing as above, filling the actual data
            foreach (var item in output)
            {
                
                TableRow tableRow = new TableRow();
                TableCell tableCell1 = new TableCell();
                TableCell tableCell2 = new TableCell();
                TableCell tableCell3 = new TableCell();

                tableCell1.Text = item[0];
                tableCell2.Text = item[1];
                tableCell3.Text = item[2];

                tableRow.Cells.Add(tableCell1);
                tableRow.Cells.Add(tableCell2);
                tableRow.Cells.Add(tableCell3);

                _tblProducts.Rows.Add(tableRow);
            }

            //styling for table header only... Couldn't figure out how to add this in the skin file
            _tblProducts.Rows[0].BackColor = Color.Aquamarine;
            _tblProducts.Rows[0].Font.Bold = true;
            _tblProducts.Rows[0].Font.Size = FontUnit.XXLarge;

        }
    }
}