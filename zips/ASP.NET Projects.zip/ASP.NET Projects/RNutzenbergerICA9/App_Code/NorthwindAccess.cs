﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace RNutzenbergerICA9
{
    public static class NorthwindAccess
    {
     
        public static string InsertOrderDetails(int orderID, int productID, short Quantity)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["rnutzenberger1_NorthwindCS"].ConnectionString);
            conn.Open();
            using(SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandText = "InsertOrderDetails";

                SqlParameter pOID = new SqlParameter("@OrderID", System.Data.SqlDbType.Int);
                SqlParameter pPID = new SqlParameter("@ProductID", System.Data.SqlDbType.Int);
                SqlParameter pQuantity = new SqlParameter("@Quantity", System.Data.SqlDbType.Int);
                SqlParameter pReturn = new SqlParameter("@retVal", System.Data.SqlDbType.Int);

                pOID.Value = orderID;
                pPID.Value = productID;
                pQuantity.Value = Quantity;
                pReturn.Value = 0;

                pOID.Direction = System.Data.ParameterDirection.Input;
                pPID.Direction = System.Data.ParameterDirection.Input;
                pQuantity.Direction = System.Data.ParameterDirection.Input;
                pReturn.Direction = System.Data.ParameterDirection.ReturnValue;

                command.Parameters.Add(pOID);
                command.Parameters.Add(pPID);
                command.Parameters.Add(pQuantity);
                command.Parameters.Add(pReturn);

                int iSPExecIgnore = command.ExecuteNonQuery();
                return "Inserted : " + pReturn.Value + " rows";
            }
        }
        public static string DeleteOrderDetails(int orderID, int productID)
        {

            string status;
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["rnutzenberger1_NorthwindCS"].ConnectionString);
            conn.Open();
            using(SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandText = "DeleteOrderDetails";

                SqlParameter pOID = new SqlParameter("@orderID", System.Data.SqlDbType.Int);
                SqlParameter pPID = new SqlParameter("@productID", System.Data.SqlDbType.Int);
                SqlParameter pStatus = new SqlParameter("@status", System.Data.SqlDbType.VarChar,80);
                SqlParameter pReturn = new SqlParameter("@retVal", System.Data.SqlDbType.Int);

                pOID.Value = orderID;
                pOID.Direction = System.Data.ParameterDirection.Input;
                pPID.Value = productID;
                pPID.Direction = System.Data.ParameterDirection.Input;
                pStatus.Value = "";
                pStatus.Direction = System.Data.ParameterDirection.Output;
                pReturn.Value = 0;
                pReturn.Direction = System.Data.ParameterDirection.ReturnValue;

                command.Parameters.Add(pOID);
                command.Parameters.Add(pPID);
                command.Parameters.Add(pStatus);
                command.Parameters.Add(pReturn);

                int iSPExecIgnore = command.ExecuteNonQuery();
                return status = (string)pStatus.Value;


            }
        }
        public static void FillCustomersDDL(string filter, DropDownList ddl)
        {
            //SqlDataReader dataReader = null;
            SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["rnutzenberger1_NorthwindCS"].ConnectionString);
            connection.Open();
            using(SqlCommand command = new SqlCommand())
            {
                //set the command type to stored procedure
                command.Connection = connection;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandText = "GetCustomers";

                //create the parameter and the value for the parameter
                SqlParameter pFilter = new SqlParameter("@filter", System.Data.SqlDbType.VarChar, 25);

                pFilter.Value = filter;
                pFilter.Direction = System.Data.ParameterDirection.Input;

                //add the parameter
                command.Parameters.Add(pFilter);

                //execute command
                ddl.DataSource = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                ddl.DataTextField = "CompanyName";
                ddl.DataValueField = "CustomerID";
                ddl.Items.Clear();
                ddl.DataBind();
                ddl.Items.Insert(0, new ListItem($"Pick a Customer From [{ddl.Items.Count}]", ""));
                ddl.AutoPostBack = true;
            }
            
        }

        public static SqlDataReader CustomerCategorySummary(string CustID)
        {
            SqlDataReader reader = null;
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["rnutzenberger1_NorthwindCS"].ConnectionString);
            conn.Open();
            using (SqlCommand command = new SqlCommand())
            {
                //set the command type to stored procedure
                command.Connection = conn;
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandText = "CustCatSummary";

                SqlParameter pID = new SqlParameter("@custID", System.Data.SqlDbType.NChar, 5);
                pID.Value = CustID;
                pID.Direction = System.Data.ParameterDirection.Input;

                command.Parameters.Add(pID);

                return reader = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
            }
        }

        public static SqlDataSource GetSuppliersSDS(string sFilter)
        {
            //build query to retrieve companys matching the filter
            string query = "SELECT SupplierID, CompanyName from Suppliers";
            query += " where CompanyName like '%"+sFilter+"%'";

            //create the datasource and return
            SqlDataSource sds = new SqlDataSource(ConfigurationManager.ConnectionStrings["rnutzenberger1_NorthwindCS"].ConnectionString, query);
            return sds;
        }

        public static List<List<string>> GetProducts(string SupplierID)
        {
            //make return object
            List<List<string>> ret = new List<List<string>>();

            //build the query where it matches the supplied ID
            string query = "select p.ProductName, p.QuantityPerUnit, p.UnitsInStock";
            query += " from Products p join Suppliers s on p.SupplierID = s.SupplierID";
            query += " where s.SupplierID = '" + SupplierID + "'";
            query += " order by p.ProductName";

            //open the sql connection to the northwindDB using existing CS
            using(SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["rnutzenberger1_NorthwindCS"].ConnectionString))
            {
                //create sql command for the query on the connection
                using(SqlCommand command = new SqlCommand(query, conn))
                {
                    //open the connection to the DB
                    conn.Open();

                    //execute the query
                    SqlDataReader reader = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection);

                    //if there are no results, then return nothing
                    if (!reader.HasRows)
                    {
                        return ret;
                    }

                    //first list of string holds the column names, iterate through the fields and daa the names
                    List<string> columns = new List<string>();
                    for (int i = 0; i< reader.FieldCount; ++i)
                    {
                        columns.Add(reader.GetName(i));
                    }
                    //add it to the return object
                    ret.Add(columns);

                    //iterate through the data 
                    while (reader.Read())
                    {
                        //create a list of string data
                        List<string> rowData = new List<string>();
                        
                        //add each data field corresponding to the column
                        rowData.Add(reader["ProductName"].ToString());
                        rowData.Add(reader["QuantityPerUnit"].ToString());
                        rowData.Add(reader["UnitsInStock"].ToString());
                        //add the rowData to the return object
                        ret.Add(rowData);
                    }

                }
            }
            return ret;

        }
    
    }
}