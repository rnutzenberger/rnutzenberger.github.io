﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Drawing;

namespace RNutzenbergerICA9
{
    public partial class ica09_RyanNutzenberger : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void _gvDB_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //check if a null value of is being bound and return
            if (e == null || e.Row == null || e.Row.DataItem == null) return;

            DataRowView drv = e.Row.DataItem as DataRowView;
            
            short stock = (short)drv["UnitsInStock"];       //how many in stock
            decimal price = (decimal)drv["UnitPrice"];      //price of item
            short onOrder = (short)drv["UnitsOnOrder"];     //how many on order
            //if the row stock is less than 25, set color to show
            if (stock < 25)
            {
                e.Row.BackColor = Color.LightSalmon;
            }
            //if price is less than 25, set color to show that cell only
            if (price > 25)
            {
                e.Row.Cells[5].BackColor = Color.Yellow;
            }
            //if both stock and on order meets params, set colors to row and cell
            if(stock < 20 && onOrder < 5)
            {
                e.Row.BackColor = Color.Cyan;
                e.Row.Cells[6].BackColor = Color.GreenYellow;
            }

           



        }

        protected void _btnShow_Click(object sender, EventArgs e)
        {
            _mv.SetActiveView(_view1);
        }

        protected void _btnEdit_Click(object sender, EventArgs e)
        {
            _mv.SetActiveView(_view2);
        }
    }
}