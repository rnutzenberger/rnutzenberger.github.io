﻿use rnutzenberger1_Northwind
go

if exists(select * from sysobjects where name = 'GetCustomers')
	drop procedure GetCustomers
go
create procedure GetCustomers
@filter as varchar(25) = ''
as 
begin

	select c.CustomerID, c.CompanyName
	from Customers c
	where c.CompanyName like '%'+@filter+'%'
	order by c.CompanyName
end
go

if exists(select * from sysobjects where name = 'CustCatSummary')
	drop procedure CustCatSummary
go
create procedure CustCatSummary
@custID as nchar(5)
as 
begin

	select ca.CategoryName, SUM(od.Quantity) as 'Total', SUM(od.Quantity * od.UnitPrice) as 'Costs'
	from Customers cu join Orders o on o.CustomerID = cu.CustomerID
		join [Order Details] od on od.OrderID = o.OrderID
		join Products p on p.ProductID = od.ProductID
		join Categories ca on ca.CategoryID = p.CategoryID
		where cu.CustomerID = @custID
		group by ca.CategoryName
		order by [Total] desc
end
go


if exists(select * from sysobjects where name = 'DeleteOrderDetails')
	drop procedure DeleteOrderDetails
go
create procedure DeleteOrderDetails
@orderID as int,
@productID as int,
@status as varchar(80) out
as
begin
declare @rows as int
declare @retVal as int

	select * from [Order Details]
	where OrderID = @orderID and ProductID = @productID
	set @rows = @@ROWCOUNT
if (@rows = 0)
begin
	set @status = 'No records deleted, possible error.'
	set @retVal = -1
	return @retVal
end


delete from [Order Details] where
	OrderID = @orderID and ProductID = @productID
	set @status = 'Record deleted.'
	set @retVal = 0
	return @retVal
end
go



if exists(select * from sysobjects where name = 'InsertOrderDetails')
	drop procedure InsertOrderDetails
go
create procedure InsertOrderDetails
@OrderID as int,
@ProductID as int,
@Quantity as int
as 
begin
declare @Discount as int = 0
declare @Price as money
declare @retVal as int

if not exists(select OrderID from Orders where OrderID = @OrderID)
begin
	set @retVal = 0
	return @retVal
end
if not exists(select ProductID from Products where ProductID = @ProductID)
begin
	set @retVal = 0
	return @retVal
end
if exists(select * from [Order Details] od
		JOIN Orders o on o.OrderID = od.OrderID
		JOIN Products p on p.ProductID = od.ProductID
		where  o.OrderID = @OrderID AND p.ProductID = @ProductID)
begin
	set @retVal = -1
	return @retVal
end

select @Price = UnitPrice
from Products
where ProductID = @ProductID


insert into [Order Details](OrderID,ProductID,Quantity,UnitPrice,Discount)
values(@OrderID,@ProductID, @Quantity, @Price, @Discount)
return @@ROWCOUNT


end
go
