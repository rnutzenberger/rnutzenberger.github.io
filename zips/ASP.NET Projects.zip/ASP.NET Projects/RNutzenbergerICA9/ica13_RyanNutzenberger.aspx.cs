﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RNutzenbergerICA9
{
    public partial class ica13_RyanNutzenberger : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void _btnDelete_Click(object sender, EventArgs e)
        {
            //try get values from the gridview and deleted the row
            try
            {
                int OID = (int)GridView1.SelectedDataKey.Values["OrderID"];
                int PID = (int)GridView1.SelectedDataKey.Values["ProductID"];
                _lblStatus.Text = NorthwindAccess.DeleteOrderDetails(OID, PID); 
            }
            catch(Exception ex)
            {
                //catch if no values could be grabbed (nothing selected) display the error
                _lblStatus.Text = ex.Message;
            }

            GridView1.DataBind();
        }

        protected void _btnInsert_Click(object sender, EventArgs e)
        {
            //try and parse out the orderID from the textbox
            if(int.TryParse(_txbOrderID.Text,out int OID))
            {
                //parse the selected value from the ddl
                int PID = int.Parse(_ddlProducts.SelectedValue);
                //then try parse the quantity text
                if(short.TryParse(_txbQuantity.Text, out short Quanitity))
                {
                    try
                    {
                        //try insert the order
                        _lblStatus2.Text = NorthwindAccess.InsertOrderDetails(OID, PID, Quanitity);

                    }
                    //catch will display the error message
                    catch(Exception ex)
                    {
                        _lblStatus2.Text = ex.Message;
                    }
                }
            }
            GridView1.DataBind();
            GridView1.SelectedIndex = -1;
        }

        protected void _ddlProducts_DataBound(object sender, EventArgs e)
        {
            _ddlProducts.Items.Insert(0, new ListItem("Pick a Product", ""));
        }
    }
}