﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RNutzenbergerICA9
{
    public partial class ica_10RyanNutzenberger : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void _LVOrders_SelectedIndexChanged(object sender, EventArgs e)
        {
            _DVSelect.PageIndex = 0;
        }

        protected void _DDLCustomers_SelectedIndexChanged(object sender, EventArgs e)
        {
            _DVSelect.PageIndex = 0;
            _LVOrders.SelectedIndex = -1;
            DataPager dp = _LVOrders.FindControl("DataPager1") as DataPager;
            dp.SetPageProperties(0, dp.MaximumRows, true);
        }
    }
}